# settings_app/models.py
# Agent-3: Settings Manager — Django Model

from django.db import models
from django.contrib.auth.models import User


class UserSettings(models.Model):
    """
    เก็บการตั้งค่าทั้งหมดของผู้ใช้แต่ละคน
    (one-to-one กับ User)
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='settings')

    # ---- 1. Font ----
    FONT_CHOICES = [
        ("'Sarabun', sans-serif",            "Sarabun (ภาษาไทย)"),
        ("'Prompt', sans-serif",             "Prompt"),
        ("'Kanit', sans-serif",              "Kanit"),
        ("'IBM Plex Sans Thai', sans-serif", "IBM Plex Sans Thai"),
        ("'Noto Sans Thai', sans-serif",     "Noto Sans Thai"),
        ("'Mitr', sans-serif",               "Mitr"),
    ]
    font_family  = models.CharField(max_length=80,  default="'Sarabun', sans-serif", choices=FONT_CHOICES)
    font_size    = models.PositiveIntegerField(default=16)
    font_color   = models.CharField(max_length=10,  default="#212529")

    # ---- 2. Header h1–h6 ----
    h1_size  = models.FloatField(default=2.0);   h1_color = models.CharField(max_length=10, default="#B8860B")
    h2_size  = models.FloatField(default=1.7);   h2_color = models.CharField(max_length=10, default="#B8860B")
    h3_size  = models.FloatField(default=1.5);   h3_color = models.CharField(max_length=10, default="#333333")
    h4_size  = models.FloatField(default=1.3);   h4_color = models.CharField(max_length=10, default="#333333")
    h5_size  = models.FloatField(default=1.1);   h5_color = models.CharField(max_length=10, default="#555555")
    h6_size  = models.FloatField(default=0.875); h6_color = models.CharField(max_length=10, default="#6c757d")

    # ---- 3. Receipt ----
    RECEIPT_STYLES = [
        ('classic',   'Classic'),
        ('modern',    'Modern'),
        ('minimal',   'Minimal'),
        ('corporate', 'Corporate'),
    ]
    receipt_style   = models.CharField(max_length=20, default='classic', choices=RECEIPT_STYLES)
    receipt_header  = models.CharField(max_length=200, blank=True)
    receipt_address = models.TextField(blank=True)
    receipt_tax_id  = models.CharField(max_length=50, blank=True)
    receipt_color   = models.CharField(max_length=10, default="#B8860B")
    receipt_footer  = models.CharField(max_length=200, default="ขอบคุณที่ใช้บริการ")

    # ---- 4. Button ----
    BTN_STYLES = [
        ('filled',   'Filled'),
        ('outline',  'Outline'),
        ('soft',     'Soft'),
        ('gradient', 'Gradient'),
    ]
    btn_style  = models.CharField(max_length=20, default='filled', choices=BTN_STYLES)
    btn_radius = models.FloatField(default=0.375)
    btn_size   = models.CharField(max_length=5, blank=True, default='')

    # ---- 5. Company ----
    company_name     = models.CharField(max_length=200, blank=True)
    company_url      = models.URLField(blank=True)
    company_phone    = models.CharField(max_length=50, blank=True)
    company_email    = models.EmailField(blank=True)
    company_policy   = models.TextField(blank=True, default="All rights reserved.")
    company_address  = models.TextField(blank=True)
    company_tax_id   = models.CharField(max_length=50, blank=True)
    company_currency = models.CharField(max_length=5, default="THB")
    lang             = models.CharField(max_length=5, default="th")

    # ---- 6. Theme ----
    theme           = models.CharField(max_length=10, default='light', choices=[('light','Light'),('dark','Dark')])
    primary_color   = models.CharField(max_length=10, default="#B8860B")
    secondary_color = models.CharField(max_length=10, default="#DAA520")

    # ---- 7. Advanced ----
    sidebar_width      = models.PositiveIntegerField(default=260)
    header_height      = models.PositiveIntegerField(default=60)
    date_format        = models.CharField(max_length=20, default="d/m/Y")
    rows_per_page      = models.PositiveIntegerField(default=25)
    enable_animations  = models.BooleanField(default=True)
    compact_mode       = models.BooleanField(default=False)
    show_breadcrumb    = models.BooleanField(default=True)

    class Meta:
        verbose_name        = "การตั้งค่าผู้ใช้"
        verbose_name_plural = "การตั้งค่าผู้ใช้"

    def __str__(self):
        return f"Settings({self.user.username})"

    @classmethod
    def get_for_user(cls, user):
        """Helper: get or create settings for user"""
        obj, _ = cls.objects.get_or_create(user=user)
        return obj


# ─────────────────────────────────────────────────────────────
# settings_app/views.py
# ─────────────────────────────────────────────────────────────

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.http import JsonResponse
from django.contrib import messages
# from .models import UserSettings  (uncomment in real project)


@login_required
def settings_index(request):
    """
    Agent-3: Settings Manager — หน้าตั้งค่าหลัก
    """
    user_settings = UserSettings.get_for_user(request.user)

    color_presets = [
        {"name": "Gold",     "color": "#B8860B"},
        {"name": "Blue",     "color": "#1a73e8"},
        {"name": "Green",    "color": "#34a853"},
        {"name": "Red",      "color": "#dc3545"},
        {"name": "Purple",   "color": "#6f42c1"},
        {"name": "Orange",   "color": "#fd7e14"},
        {"name": "Teal",     "color": "#20c997"},
        {"name": "Dark",     "color": "#343a40"},
    ]

    context = {
        'settings':      user_settings,
        'color_presets': color_presets,
        'font_choices':  UserSettings.FONT_CHOICES,
        'receipt_styles': [
            {'value': v, 'label': l} for v, l in UserSettings.RECEIPT_STYLES
        ],
    }
    return render(request, 'settings/index.html', context)


@login_required
@require_POST
def settings_save(request):
    """
    Agent-3: บันทึกการตั้งค่าทั้งหมด
    """
    s = UserSettings.get_for_user(request.user)
    post = request.POST

    # 1. Font
    s.font_family = post.get('font_family', s.font_family)
    s.font_size   = int(post.get('font_size', s.font_size) or s.font_size)
    s.font_color  = post.get('font_color', s.font_color)

    # 2. Headers
    for tag in range(1, 7):
        setattr(s, f'h{tag}_size',
                float(post.get(f'h{tag}_size') or getattr(s, f'h{tag}_size')))
        setattr(s, f'h{tag}_color',
                post.get(f'h{tag}_color', getattr(s, f'h{tag}_color')))

    # 3. Receipt
    s.receipt_style   = post.get('receipt_style',   s.receipt_style)
    s.receipt_header  = post.get('receipt_header',  s.receipt_header)
    s.receipt_address = post.get('receipt_address', s.receipt_address)
    s.receipt_tax_id  = post.get('receipt_tax_id',  s.receipt_tax_id)
    s.receipt_color   = post.get('receipt_color',   s.receipt_color)
    s.receipt_footer  = post.get('receipt_footer',  s.receipt_footer)

    # 4. Button
    s.btn_style  = post.get('btn_style',  s.btn_style)
    s.btn_radius = float(post.get('btn_radius') or s.btn_radius)
    s.btn_size   = post.get('btn_size',   s.btn_size)

    # 5. Company
    s.company_name     = post.get('company_name',    s.company_name)
    s.company_url      = post.get('company_url',     s.company_url)
    s.company_phone    = post.get('company_phone',   s.company_phone)
    s.company_email    = post.get('company_email',   s.company_email)
    s.company_policy   = post.get('company_policy',  s.company_policy)
    s.company_address  = post.get('company_address', s.company_address)
    s.company_tax_id   = post.get('company_tax_id',  s.company_tax_id)
    s.company_currency = post.get('company_currency',s.company_currency)
    s.lang             = post.get('lang',            s.lang)

    # 6. Theme
    s.theme           = post.get('theme',           s.theme)
    s.primary_color   = post.get('primary_color',   s.primary_color)
    s.secondary_color = post.get('secondary_color', s.secondary_color)

    # 7. Advanced
    s.sidebar_width     = int(post.get('sidebar_width')  or s.sidebar_width)
    s.header_height     = int(post.get('header_height')  or s.header_height)
    s.date_format       = post.get('date_format',    s.date_format)
    s.rows_per_page     = int(post.get('rows_per_page')  or s.rows_per_page)
    s.enable_animations = 'enable_animations' in post
    s.compact_mode      = 'compact_mode' in post
    s.show_breadcrumb   = 'show_breadcrumb' in post

    s.save()

    # บันทึก theme ลง session ด้วย (ใช้ใน base.html)
    request.session['theme'] = s.theme

    messages.success(request, "✅ บันทึกการตั้งค่าเรียบร้อยแล้ว")
    return redirect('settings:index')


@login_required
def settings_reset(request):
    """รีเซ็ตการตั้งค่าทั้งหมดกลับค่าเริ่มต้น"""
    UserSettings.objects.filter(user=request.user).delete()
    messages.info(request, "🔄 รีเซ็ตการตั้งค่าเรียบร้อยแล้ว")
    return redirect('settings:index')


@login_required
@require_POST
def set_theme(request):
    """
    Agent-6: AJAX endpoint สำหรับ toggle theme
    เรียกจาก JS ใน base.html
    """
    import json
    data  = json.loads(request.body)
    theme = data.get('theme', 'light')
    request.session['theme'] = theme
    # บันทึกลง UserSettings ด้วย
    s = UserSettings.get_for_user(request.user)
    s.theme = theme
    s.save(update_fields=['theme'])
    return JsonResponse({'status': 'ok', 'theme': theme})


# ─────────────────────────────────────────────────────────────
# settings_app/context_processors.py
# ─────────────────────────────────────────────────────────────
# เพิ่มใน settings.py → TEMPLATES[0]['OPTIONS']['context_processors']
#   'settings_app.context_processors.user_settings',

def user_settings_processor(request):
    """
    Inject user_settings ให้ทุก template โดยอัตโนมัติ
    ใช้ใน base.html ผ่าน {{ user_settings.xxx }}
    """
    if request.user.is_authenticated:
        try:
            settings = request.user.settings
        except Exception:
            settings = UserSettings.get_for_user(request.user)
        return {'user_settings': settings}
    return {'user_settings': None}


# ─────────────────────────────────────────────────────────────
# settings_app/urls.py
# ─────────────────────────────────────────────────────────────

from django.urls import path
# from . import views

app_name = 'settings'

urlpatterns = [
    path('',          settings_index, name='index'),
    path('save/',     settings_save,  name='save'),
    path('reset/',    settings_reset, name='reset'),
    path('set-theme/', set_theme,     name='set_theme'),
]


# ─────────────────────────────────────────────────────────────
# project/urls.py  (snippet เพิ่ม path)
# ─────────────────────────────────────────────────────────────
# from django.urls import path, include
#
# urlpatterns = [
#     path('admin/',     admin.site.urls),
#     path('',           include('dashboard.urls', namespace='dashboard')),
#     path('settings/',  include('settings_app.urls', namespace='settings')),
#     path('receipt/',   include('receipt.urls',      namespace='receipt')),
#     path('accounts/',  include('accounts.urls',     namespace='accounts')),
# ]
