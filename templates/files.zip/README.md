# 🤖 Agent Team: Bootstrap5 + Django Analytics Dashboard
## คู่มือการใช้งาน (Codex A Standard)

---

## 📁 โครงสร้างไฟล์

```
project/
├── templates/
│   ├── base.html                  ← Agent-1: Layout & Base
│   ├── dashboard/
│   │   └── index.html             ← Agent-4: Chart Builder
│   ├── settings/
│   │   └── index.html             ← Agent-3: Settings Manager
│   └── receipt/
│       └── detail.html            ← Agent-5: Receipt Designer
│
├── settings_app/
│   ├── models.py                  ← UserSettings model
│   ├── views.py                   ← Settings views
│   ├── urls.py                    ← URL routing
│   └── context_processors.py     ← Global template injection
│
└── AGENT_TEAM_SYSTEM.md           ← Agent Team Specification
```

---

## ⚙️ การติดตั้ง Django

### 1. เพิ่ม App ใน settings.py
```python
INSTALLED_APPS = [
    ...
    'settings_app',
    'dashboard',
    'receipt',
]

TEMPLATES = [{
    'OPTIONS': {
        'context_processors': [
            ...
            'settings_app.context_processors.user_settings_processor',
        ],
    }
}]
```

### 2. URL Configuration
```python
# project/urls.py
from django.urls import path, include

urlpatterns = [
    path('admin/',    admin.site.urls),
    path('',          include('dashboard.urls', namespace='dashboard')),
    path('settings/', include('settings_app.urls', namespace='settings')),
    path('receipt/',  include('receipt.urls',      namespace='receipt')),
    path('accounts/', include('accounts.urls',     namespace='accounts')),
]
```

### 3. Migrate
```bash
python manage.py makemigrations settings_app
python manage.py migrate
```

---

## 🧩 Bootstrap Icons ที่ใช้ได้

Library: `bootstrap-icons@1.11.3` (โหลดจาก CDN อัตโนมัติใน base.html)

```html
<!-- การใช้งาน -->
<i class="bi bi-bar-chart-fill"></i>      <!-- กราฟแท่ง -->
<i class="bi bi-grid-1x2-fill"></i>       <!-- แดชบอร์ด -->
<i class="bi bi-folder2-open"></i>        <!-- โฟลเดอร์ -->
<i class="bi bi-file-earmark-text"></i>   <!-- ไฟล์ -->
<i class="bi bi-receipt"></i>             <!-- ใบเสร็จ -->
<i class="bi bi-gear-fill"></i>           <!-- ตั้งค่า -->
<i class="bi bi-palette"></i>             <!-- สี/Theme -->
<i class="bi bi-sun-fill"></i>            <!-- โหมดสว่าง -->
<i class="bi bi-moon-fill"></i>           <!-- โหมดมืด -->
<i class="bi bi-piggy-bank"></i>          <!-- ออมทรัพย์ -->
<i class="bi bi-graph-down-arrow"></i>    <!-- GAP -->
<i class="bi bi-shop"></i>                <!-- ร้านค้า -->
<i class="bi bi-building"></i>            <!-- บริษัท -->
<i class="bi bi-printer"></i>             <!-- พิมพ์ -->
<i class="bi bi-download"></i>            <!-- ดาวน์โหลด -->
<i class="bi bi-bell"></i>                <!-- แจ้งเตือน -->
<i class="bi bi-person-fill"></i>         <!-- ผู้ใช้ -->
```

---

## 🎨 CSS Variables (ปรับตาม Settings)

```css
:root {
  --app-primary:      /* สีหลัก (จาก primary_color) */
  --app-secondary:    /* สีรอง */
  --app-font-family:  /* ฟอนต์ */
  --app-font-size:    /* ขนาดฟอนต์ */
  --app-h1-size:      /* ขนาด h1 */
  --app-h1-color:     /* สี h1 */
  --app-btn-radius:   /* ความโค้งปุ่ม */
  --sidebar-width:    /* ความกว้าง sidebar */
  --header-height:    /* ความสูง header */
}
```

---

## 🔘 Button Styles (4 รูปแบบ)

```html
<!-- Style 1: Filled (ทึบ) -->
<button class="btn btn-app btn-app-filled">บันทึก</button>

<!-- Style 2: Outline (เส้นขอบ) -->
<button class="btn btn-app btn-app-outline">ยกเลิก</button>

<!-- Style 3: Soft/Ghost (นุ่ม) -->
<button class="btn btn-app btn-app-soft">ดูเพิ่มเติม</button>

<!-- Style 4: Gradient (ไล่สี) -->
<button class="btn btn-app btn-app-gradient">ยืนยัน</button>
```

---

## 📧 Template Tags ที่ใช้บ่อย

```django
{% load humanize %}

{{ value|intcomma }}           {# 1,234,567 #}
{{ value|floatformat:2 }}      {# 1234.56 #}
{{ date|date:"d/m/Y" }}        {# 01/01/2021 #}
{% now "Y" %}                  {# 2024 #}
{{ text|truncatechars:50 }}    {# ตัดข้อความ #}
{{ user.get_full_name }}       {# ชื่อเต็ม #}
```

---

## 📊 การส่งข้อมูล Chart จาก Django View

```python
# dashboard/views.py
import json
from django.shortcuts import render

def dashboard_index(request):
    context = {
        'kpi': {
            'total_projects': 26,
            'loi_issued':     290549834,
            'monthly':        157958693,
            'savings':        36842682,
            'pl1': 1, 'pl2': 62,
            'gap1': '-4,252,455',
            'gap2': '-3,354,174',
            'retail_sales': 24905000,
        },
        # ส่งข้อมูลกราฟเป็น JSON string
        'area_loi':    json.dumps([40, 55, 48, 70, 65, 90]),
        'area_tx':     json.dumps([30, 40, 35, 55, 50, 70]),
        'branch_data': json.dumps([45, 65, 85]),
        'actual_april': json.dumps([800, 950, 1100, 1000, 1200, 1100, 1200]),
    }
    return render(request, 'dashboard/index.html', context)
```

---

## 🤖 วิธีใช้ Agent แต่ละตัว

### Agent-1: สร้าง Page ใหม่
```
"สร้างหน้า [ชื่อหน้า] โดยใช้ base.html"
→ ผลลัพธ์: template ที่ extends base.html พร้อม block content
```

### Agent-3: ปรับ Settings
```
"เพิ่ม option ตั้งค่า [X] ในหน้า Settings"
→ ผลลัพธ์: field ใน model + form field ใน template + save ใน view
```

### Agent-4: เพิ่ม Chart
```
"เพิ่ม [ชนิด] chart แสดงข้อมูล [Y] ในหน้า [Z]"
→ ผลลัพธ์: canvas + Chart.js config + Django view data
```

### Agent-5: ออกแบบใบเสร็จ
```
"ปรับ style ใบเสร็จ [classic/modern/minimal/corporate]"
→ ผลลัพธ์: receipt template + print CSS
```

### Agent-6: เปลี่ยน Theme
```
"เปลี่ยนสีหลักเป็น [สี] / เปลี่ยนเป็น dark mode"
→ ผลลัพธ์: CSS variable update + localStorage + Django session
```

---

## 📌 หมายเหตุสำคัญ (Codex A)

1. **Bootstrap 5 เท่านั้น** — หากต้องการ library อื่น (Chart.js, etc.) ต้องขออนุญาตก่อน
2. **ทุก template ต้อง** `{% extends 'base.html' %}` และ `{% load static humanize %}`
3. **CSS Variables** สำหรับ colors เสมอ ไม่ hardcode hex
4. **Dark/Light mode** ผ่าน `data-bs-theme` ไม่เขียน CSS แยก
5. **Form ทุกตัว** ต้องมี `{% csrf_token %}`
6. **ข้อมูลสำคัญ** ผ่าน Django template variables ไม่ hardcode ใน template
